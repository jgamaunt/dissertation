
For troubleshooting GitHuB Actions, a helpful tool is [act](https://github.com/nektos/act).

The most common use case is just running `act` with no arguments to test GitHub actions.
