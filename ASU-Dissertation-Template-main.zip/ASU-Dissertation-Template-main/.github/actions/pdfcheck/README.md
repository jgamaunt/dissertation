Check whether attributes of a PDF match the
[ASU dissertation/thesis style guide]<https://graduate.asu.edu/sites/default/files/asu-graduate-college-format-manual.pdf>
(last updated January 2017).
