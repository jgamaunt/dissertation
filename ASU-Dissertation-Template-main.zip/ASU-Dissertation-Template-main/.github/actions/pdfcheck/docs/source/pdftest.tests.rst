pdfcheck.tests package
=====================

Submodules
----------

pdfcheck.tests.basic module
--------------------------

.. automodule:: pdfcheck.tests.basic
   :members:
   :undoc-members:
   :show-inheritance:

pdfcheck.tests.font module
-------------------------

.. automodule:: pdfcheck.tests.font
   :members:
   :undoc-members:
   :show-inheritance:

pdfcheck.tests.margins module
----------------------------

.. automodule:: pdfcheck.tests.margins
   :members:
   :undoc-members:
   :show-inheritance:

pdfcheck.tests.title\_page module
--------------------------------

.. automodule:: pdfcheck.tests.title_page
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pdfcheck.tests
   :members:
   :undoc-members:
   :show-inheritance:
